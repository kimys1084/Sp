------2016-21191 yongsungkim hw3

how to exec:

just ./HW3 or if you want to re - make project, just type make and execute.

or if you type ./exec.sh -> shell file will make and execute project

implement

obj loader
multi light -> num key 1 2 3( 2, 3 spot lights)
phong shading


2016-21191 yongsung kim
