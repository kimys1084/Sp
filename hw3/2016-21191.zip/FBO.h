void init

void genFrameBuffer(){


	GLenum FBOstatus;
//Generating
	glGenFramebuffers(1, &Fb0);
	glGenTextures(1, &Tx0);
	glGenRenderbuffers(1, &Rb0);

	//Binding
	glBindTexture(GL_TEXTURE_2D, Tx0);
	glBindFramebuffer(GL_FRAMEBUFFER, Fb0);
	glBindRenderbuffer(GL_RENDERBUFFER, Rb0);

	glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, 512, 512, 0, GL_RGB, GL_UNSIGNED_BYTE, 0);
	glRenderbufferStorage(GL_RENDERBUFFER, GL_DEPTH_COMPONENT24, 512, 512);

	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);


	glFramebufferRenderbuffer(GL_FRAMEBUFFER, GL_DEPTH_ATTACHMENT, GL_RENDERBUFFER, Rb0);
	glFramebufferTexture2D(GL_FRAMEBUFFER, GL_COLOR_ATTACHMENT0,GL_TEXTURE_2D,  Tx0, 0);

	//Depth

	//Generating
	glGenFramebuffers(13, &Fb1[0]);
	glGenTextures(13, &Tx1[0]);


	for(int i = 0; i<13; i++){
		glBindTexture(GL_TEXTURE_2D, Tx1[i]);
		glBindFramebuffer(GL_FRAMEBUFFER, Fb1[i]);
		glTexImage2D(GL_TEXTURE_2D, 0, GL_DEPTH_COMPONENT24, 512, 512, 0, GL_DEPTH_COMPONENT, GL_FLOAT, 0);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
		glFramebufferTexture2D(GL_FRAMEBUFFER, GL_DEPTH_ATTACHMENT, GL_TEXTURE_2D, Tx1[i], 0);
	}

	//Init
	glBindTexture(GL_TEXTURE_2D, 0);
	glBindRenderbuffer(GL_RENDERBUFFER, 0);

	FBOstatus = glCheckFramebufferStatusEXT(GL_FRAMEBUFFER_EXT);
	if(FBOstatus != GL_FRAMEBUFFER_COMPLETE_EXT)
		printf("GL_FRAMEBUFFER_COMPLETE_EXT failed, CANNOT use FBO\n");
	
	glBindFramebuffer(GL_FRAMEBUFFER, 0);



	return;
}