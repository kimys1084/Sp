clear
make clean
make
./HW3
