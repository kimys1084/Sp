how to exec:

just ./HW2 or if you want to re - make project, just type make and execute.

or if you type ./exec.sh -> shell file will make and execute project

2016-21191 yongsung kim
