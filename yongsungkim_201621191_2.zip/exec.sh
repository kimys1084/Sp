clear
make clean
make
./HW2
